package yujin;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.table.DefaultTableModel;


public class Product extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
	//		public void run() {
	//			try {
	//				Employee frame = new Employee();
	//				frame.setVisible(true);
//				} catch (Exception e) {
	//				e.printStackTrace();
	//			}
		//	}
	//	});
//	}

	/**
	 * Create the frame.
	 */

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	public void table () {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", "root", "admin");
			String sql = "Select * from product";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(Exception ex) {
			
			JOptionPane.showMessageDialog(null, ex);
			
		}
	}
	
	public Product() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnSupplier = new JButton("Supplier");
		btnSupplier.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnSupplier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnSupplier.setForeground(Color.WHITE);
		btnSupplier.setBackground(new Color(0, 153, 255));
		btnSupplier.setBounds(0, 305, 148, 51);
		contentPane.add(btnSupplier);
		
		JButton btnDelivery = new JButton("Delivery");
		btnDelivery.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnDelivery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnDelivery.setForeground(Color.WHITE);
		btnDelivery.setBackground(new Color(0, 153, 255));
		btnDelivery.setBounds(0, 255, 148, 51);
		contentPane.add(btnDelivery);
		
		JButton btnCustomers = new JButton("Customers");
		btnCustomers.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnCustomers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnCustomers.setForeground(Color.WHITE);
		btnCustomers.setBackground(new Color(0, 153, 255));
		btnCustomers.setBounds(0, 155, 148, 51);
		contentPane.add(btnCustomers);
		
		JButton btnProducts = new JButton("Products");
		btnProducts.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnProducts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnProducts.setForeground(Color.WHITE);
		btnProducts.setBackground(new Color(135, 206, 250));
		btnProducts.setBounds(0, 51, 148, 51);
		contentPane.add(btnProducts);
		
		JButton btnNewButton = new JButton("Edit");
		btnNewButton.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EditProduct frame = new EditProduct();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(614, 329, 92, 27);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(181, 90, 525, 216);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Product ID", "Product Name", "Product Price", "Product Quantity", "Product ExDate"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(84);
		table.getColumnModel().getColumn(1).setPreferredWidth(107);
		table.getColumnModel().getColumn(2).setPreferredWidth(105);
		table.getColumnModel().getColumn(3).setPreferredWidth(130);
		table.getColumnModel().getColumn(4).setPreferredWidth(125);
		
		JButton btnNewButton_1 = new JButton("Employees");
		btnNewButton_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setBackground(new Color(0, 153, 255));
		btnNewButton_1.setBounds(0, 102, 148, 56);
		contentPane.add(btnNewButton_1);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 205, 148, 51);
		contentPane.add(btnOrders);
		
		JLabel label_1 = new JLabel("Grocery Inventory Management System");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label_1.setBounds(233, 25, 385, 27);
		contentPane.add(label_1);
	}
}
