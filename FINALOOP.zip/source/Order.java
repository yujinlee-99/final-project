package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Order extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Order frame = new Order();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	public void table () {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", "root", "admin");
			String sql = "Select * from orders";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(Exception ex) {
			
			JOptionPane.showMessageDialog(null, ex);
			
		}
	}
	
	public Order() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("Products");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(0, 153, 255));
		button.setBounds(0, 52, 148, 51);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Employees");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(0, 153, 255));
		button_1.setBounds(0, 100, 148, 51);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Customers");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(0, 153, 255));
		button_2.setBounds(0, 151, 148, 51);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Orders");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(135, 206, 250));
		button_3.setBounds(0, 202, 148, 51);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("Delivery");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_4.setForeground(Color.WHITE);
		button_4.setBackground(new Color(0, 153, 255));
		button_4.setBounds(0, 253, 148, 51);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("Supplier");
		button_5.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_5.setForeground(Color.WHITE);
		button_5.setBackground(new Color(0, 153, 255));
		button_5.setBounds(0, 304, 148, 51);
		contentPane.add(button_5);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(162, 87, 566, 193);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Order_ID", "Order_Date", "Product_ID", "Quantity", "TotalPrice", "Customer_ID"
			}
		));
		
		JButton button_6 = new JButton("Edit");
		button_6.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EditOrder frame = new EditOrder();
				frame.setVisible(true);
				dispose();
			}
		});
		button_6.setBounds(636, 328, 92, 27);
		contentPane.add(button_6);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(247, 22, 385, 27);
		contentPane.add(label);
	}
}
