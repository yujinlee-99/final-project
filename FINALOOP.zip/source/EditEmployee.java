package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class EditEmployee extends JFrame {

	private JPanel contentPane;
	private JTextField employeeID;
	private JTextField EmployeeName;
	private JTextField position;
	private JTextField EmployeeID;

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JTextField cn;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditEmployee frame = new EditEmployee();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditEmployee() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("Products");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setForeground(Color.WHITE);
		button.setBackground(new Color(0, 153, 255));
		button.setBounds(0, 37, 148, 51);
		contentPane.add(button);
		
		JButton button_1 = new JButton("Employees");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(135, 206, 250));
		button_1.setBounds(0, 88, 148, 56);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Customers");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(0, 153, 255));
		button_2.setBounds(0, 143, 148, 56);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Delivery");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(0, 153, 255));
		button_3.setBounds(0, 254, 148, 51);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("Supplier");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_4.setForeground(Color.WHITE);
		button_4.setBackground(new Color(0, 153, 255));
		button_4.setBounds(0, 305, 148, 51);
		contentPane.add(button_4);
		
		JLabel lblNewLabel = new JLabel("Employee ID");
		lblNewLabel.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel.setBounds(225, 126, 105, 18);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Employee Name");
		lblNewLabel_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(225, 162, 124, 18);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Position");
		lblNewLabel_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(225, 199, 124, 18);
		contentPane.add(lblNewLabel_2);
		
		employeeID = new JTextField();
		employeeID.setBounds(363, 120, 116, 24);
		contentPane.add(employeeID);
		employeeID.setColumns(10);
		
		EmployeeName = new JTextField();
		EmployeeName.setBounds(363, 159, 116, 24);
		contentPane.add(EmployeeName);
		EmployeeName.setColumns(10);
		
		position = new JTextField();
		position.setBounds(363, 196, 116, 24);
		contentPane.add(position);
		position.setColumns(10);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					String sql = "Insert into employee" + "(Employee_ID, Employee_Name, Employee_Position, Employee_CN)" + "values (?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject?useTimezone=true&serverTimezone=UTC", "root", "admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1, employeeID.getText());
					stat.setString(2, EmployeeName.getText());
					stat.setString(3, position.getText());
					stat.setString(4, cn.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Employee Added");
					Employee Frame1 = new Employee();
					Frame1.table();
					Frame1.setVisible(true);
					
					dispose();
					
					
				} 
					
					catch(SQLException | HeadlessException ex) {
					JOptionPane.showMessageDialog(null, ex);
				}

				
			}
		});
		btnNewButton.setBounds(527, 228, 105, 27);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("Employee ID");
		lblNewLabel_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(225, 321, 105, 18);
		contentPane.add(lblNewLabel_3);
		
		EmployeeID = new JTextField();
		EmployeeID.setBounds(363, 318, 116, 24);
		contentPane.add(EmployeeID);
		EmployeeID.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					String sql = "Delete from employee where Employee_ID =?";
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject","root","admin");
					stat = conn.prepareStatement(sql);
					stat.setString(1,EmployeeID.getText());
					stat.executeUpdate();
					
				
				JOptionPane.showMessageDialog(null, "Employee Deleted");
				
				}
				catch(SQLException	| HeadlessException ex) {
				
					JOptionPane.showMessageDialog(null, ex);
			
				}

				Employee Frame1 = new Employee();	
				Frame1.table();
				Frame1.setVisible(true);
				
				dispose();
				
			}
		});
		btnNewButton_1.setBounds(527, 317, 105, 27);
		contentPane.add(btnNewButton_1);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 199, 148, 56);
		contentPane.add(btnOrders);
		
		JLabel lblNewLabel_4 = new JLabel("Contact Number");
		lblNewLabel_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		lblNewLabel_4.setBounds(225, 232, 124, 18);
		contentPane.add(lblNewLabel_4);
		
		cn = new JTextField();
		cn.setBounds(363, 229, 116, 24);
		contentPane.add(cn);
		cn.setColumns(10);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(247, 37, 385, 27);
		contentPane.add(label);
	}
}
