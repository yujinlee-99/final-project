package yujin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class cinfo extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cinfo frame = new cinfo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	public void table () {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalproject", "root", "admin");
			String sql = "Select * from customer";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(Exception ex) {
			
			JOptionPane.showMessageDialog(null, ex);
			
		}
	}
	
	public cinfo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button_1 = new JButton("Products");
		button_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product frame = new Product();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_1.setForeground(Color.WHITE);
		button_1.setBackground(new Color(0, 153, 255));
		button_1.setBounds(0, 48, 148, 51);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Customers");
		button_2.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cinfo frame = new cinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_2.setForeground(Color.WHITE);
		button_2.setBackground(new Color(135, 206, 250));
		button_2.setBounds(0, 150, 148, 51);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("Delivery");
		button_3.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dinfo frame = new dinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_3.setForeground(Color.WHITE);
		button_3.setBackground(new Color(0, 153, 255));
		button_3.setBounds(0, 252, 148, 51);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("Supplier");
		button_4.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sinfo frame = new sinfo();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		button_4.setForeground(Color.WHITE);
		button_4.setBackground(new Color(0, 153, 255));
		button_4.setBounds(0, 303, 148, 51);
		contentPane.add(button_4);
		
		JButton button = new JButton("Edit");
		button.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					EditCustomer frame = new EditCustomer();
					frame.setVisible(true);
					dispose();
			}
		});
		button.setBounds(627, 327, 92, 27);
		contentPane.add(button);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(176, 84, 543, 217);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Customer ID", "Customer Name", "Contact Number", "Order", "Address"
			}
		));
		
		JButton btnEmployee = new JButton("Employees");
		btnEmployee.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Employee frame = new Employee();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnEmployee.setForeground(Color.WHITE);
		btnEmployee.setBackground(new Color(0, 153, 255));
		btnEmployee.setBounds(0, 99, 148, 51);
		contentPane.add(btnEmployee);
		
		JButton btnOrders = new JButton("Orders");
		btnOrders.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 15));
		btnOrders.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Order frame = new Order();
				frame.table();
				frame.setVisible(true);
				dispose();
			}
		});
		btnOrders.setForeground(Color.WHITE);
		btnOrders.setBackground(new Color(0, 153, 255));
		btnOrders.setBounds(0, 201, 148, 51);
		contentPane.add(btnOrders);
		
		JLabel label = new JLabel("Grocery Inventory Management System");
		label.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		label.setBounds(249, 26, 385, 27);
		contentPane.add(label);
		table.getColumnModel().getColumn(0).setPreferredWidth(95);
		table.getColumnModel().getColumn(1).setPreferredWidth(120);
		table.getColumnModel().getColumn(2).setPreferredWidth(120);
		table.getColumnModel().getColumn(3).setPreferredWidth(68);
	}
}
